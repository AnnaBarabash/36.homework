

const list = document.querySelector('#list');

function addMovie() {
    const movie = document.getElementById('movie');

    const li = document.createElement('li');
    li.appendChild(document.createTextNode(movie.value));
    movie.value = '';

    list.appendChild(li);
}
